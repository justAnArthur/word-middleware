package com.fiit.logic.events;

import com.fiit.logic.DownData;
import com.fiit.logic.ViewData;

public interface InputEventListener {
    void onEnter(int length);

    DownData onDownEvent(MoveEvent event);

    ViewData onLeftEvent();

    ViewData onRightEvent();

    ViewData onRotateEvent();
}
