package com.fiit.logic.events;

public enum EventType {
    DOWN,
    LEFT,
    RIGHT,
    ROTATE
}
