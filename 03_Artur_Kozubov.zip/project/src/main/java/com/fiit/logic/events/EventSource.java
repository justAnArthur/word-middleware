package com.fiit.logic.events;

public enum EventSource {
    USER,
    THREAD
}
